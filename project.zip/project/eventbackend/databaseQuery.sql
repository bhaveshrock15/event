create table category(
	
	id IDENTITY,
	categoryName VARCHAR(50),
	description VARCHAR(65534),
	image_URL VARCHAR(50),
	is_active BOOLEAN,
	
	CONSTRAINT pk_category_id PRIMARY KEY (id)
	

);