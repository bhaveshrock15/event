$(function() {
	
	//Solving the active menu (navbar) problem

	switch(menu) {
	
	case 'About Us':
		$('#about').addClass('active');
		break;
	
	case 'Contact Us':
		$('#contact').addClass('active');
		break;
		
	case 'All Events':
		$('#listEvents').addClass('active');
		break;
		
	default:
		$('#listEvents').addClass('active');
		$('#a_'+ menu).addClass('active');
		break;

	}
	
});